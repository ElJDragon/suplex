<?php
include_once 'conexion.php';
session_start();
if (isset($_POST['logout'])) {

    session_abort();
    header("Location: login.php");

}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="admin.php" method="POST">
        <input type="submit" value="logout" name="logout">
    </form>
</body>
</html>