<?php
session_start();
session_abort();

?>